AegisHealth manuscript

Set main.tex as the main document. Compile with pdfLaTeX + BibTeX or Tectonic.
All required local layout, bibliography, table, and vector-figure files are included.

The supplied IEEE Access article inspired the layout; this is not an official
publisher submission class. Add real author names and affiliations before submission.
Graphs use saved project experiments; complete cloud synthesis latency is unmeasured.
